package utils.events;

public enum ChangeEvent {
    ADD,UPDATE,DELETE;
}
