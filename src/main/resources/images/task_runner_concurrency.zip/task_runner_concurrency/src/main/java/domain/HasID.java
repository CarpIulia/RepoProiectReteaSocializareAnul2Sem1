package domain;

public interface HasID<ID> {
    ID getID();
    void setID(ID id);
}



//public interface Entity<ID> {
//    ID getId();
//
//    void setId(ID id);
//}
