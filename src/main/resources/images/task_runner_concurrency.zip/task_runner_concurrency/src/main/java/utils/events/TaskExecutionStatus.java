package utils.events;

public enum TaskExecutionStatus {
    Running, Completed, Cancelled
}
